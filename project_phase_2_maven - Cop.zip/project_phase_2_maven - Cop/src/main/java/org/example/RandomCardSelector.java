package org.example;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import java.util.Collections;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.List;
import java.util.ArrayList;
import java.util.Random;

public class RandomCardSelector {
    public static ArrayList <String> randomMakerActive() {
        try {
            String json1 = new String(Files.readAllBytes(Paths.get("ActiveCards.json")));
            ArrayList <String> stringsOfActiveCards;
            stringsOfActiveCards = new Gson().fromJson(json1,new TypeToken<List<String>>(){}.getType());
            ArrayList <String> selectedActiveCards = selectRandomMembers(stringsOfActiveCards,15);
            return selectedActiveCards;

        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }
    public static ArrayList <String> randomMakerPassive(){
        try {
            String json2 = new String(Files.readAllBytes(Paths.get("PassiveCards.json")));
            ArrayList <String> stringsOfPassiveCards;
            stringsOfPassiveCards = new Gson().fromJson(json2,new TypeToken<List<String>>(){}.getType());
            ArrayList <String> selectedPassiveCards = selectRandomMembers(stringsOfPassiveCards,5);
            return selectedPassiveCards;

        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }
    public static ArrayList<String> selectRandomMembers(ArrayList<String> allMembers, int count) {
        Collections.shuffle(allMembers);
        return new ArrayList<>(allMembers.subList(0, count));
    }
    public static ArrayList<ActiveCards> getActiveRandomMembers(ArrayList<ActiveCards> list, int numberOfElements) {
        Random rand = new Random();
        ArrayList<ActiveCards> selectedElements = new ArrayList<>();

        for (int i = 0; i < numberOfElements && !list.isEmpty(); i++) {
            int randomIndex = rand.nextInt(list.size());
            selectedElements.add(list.get(randomIndex));
            list.remove(randomIndex);
        }
        return selectedElements;
    }
    public static ArrayList<PassiveCards> getPassiveRandomMembers(ArrayList<PassiveCards> list, int numberOfElements) {
        Random rand = new Random();
        ArrayList<PassiveCards> selectedElements = new ArrayList<>();

        for (int i = 0; i < numberOfElements && !list.isEmpty(); i++) {
            int randomIndex = rand.nextInt(list.size());
            selectedElements.add(list.get(randomIndex));
            list.remove(randomIndex);
        }
        return selectedElements;
    }
}
