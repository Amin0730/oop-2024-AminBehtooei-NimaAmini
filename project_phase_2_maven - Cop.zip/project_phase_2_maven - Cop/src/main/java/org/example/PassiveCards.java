package org.example;

public class PassiveCards {
    String name;
    String ability;
    String cost;
    String upgradeCost;
    String upgradeLevel;
    public PassiveCards(String name, String ability, String cost, String upgradeCost, String upgradeLevel) {
        this.name = name;
        this.ability = ability;
        this.cost = cost;
        this.upgradeCost = upgradeCost;
        this.upgradeLevel = upgradeLevel;
    }
}
